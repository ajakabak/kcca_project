-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 09, 2015 at 10:49 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `airport_db`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `airlines_tb`
-- 

CREATE TABLE `airlines_tb` (
  `id` int(11) NOT NULL,
  `company` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `planes` varchar(15) NOT NULL,
  `identity` varchar(25) NOT NULL,
  `insuarence` varchar(25) NOT NULL,
  `partners` varchar(30) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `identity` (`identity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `airlines_tb`
-- 

INSERT INTO `airlines_tb` (`id`, `company`, `country`, `planes`, `identity`, `insuarence`, `partners`, `phone`, `email`) VALUES 
(0, 'uganda airlines', 'Uganda', '10', 'password', '1st class', 'ethiopian', '098765', 'sotanget@gmail.com');

-- --------------------------------------------------------

-- 
-- Table structure for table `register_tb`
-- 

CREATE TABLE `register_tb` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(15) NOT NULL,
  `sname` varchar(15) NOT NULL,
  `sex` varchar(6) NOT NULL,
  `country` varchar(25) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `register_tb`
-- 

INSERT INTO `register_tb` (`id`, `name`, `sname`, `sex`, `country`, `occupation`, `phone`, `email`, `password`) VALUES 
(3, '', '', '', '', '', '', '', 'password'),
(4, 'Emaru', 'samuel', 'male', 'DR Congo', 'chef', '+256776489452', 'samemaru@yahoo.com', 'password'),
(5, 'Etengu', 'jona', 'male', 'Uganda', 'hustler', '+256776489467', 'jona@yahoo.com', 'password'),
(6, 'Etengu', 'jona', 'male', 'Uganda', 'hustler', '+25677648965', 'jort@yahoo.com', 'password'),
(7, 'Florence', 'Adono', 'female', 'Ethiopia', 'Princes', '+256772874027', 'flo@gmail.com', 'password'),
(8, 'Acen', 'Monica', 'female', 'KENYA', 'Student', '+256772874020', 'monica@gmail.com', 'password'),
(9, 'amal', 'rose', 'female', 'Rwanda', 'business', '0785643456', 'amal@gmail.com', 'password');

-- --------------------------------------------------------

-- 
-- Table structure for table `workers_tb`
-- 

CREATE TABLE `workers_tb` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `nation` varchar(30) NOT NULL,
  `identity` varchar(30) NOT NULL,
  `profession` varchar(30) NOT NULL,
  `experiance` varchar(10) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `workers_tb`
-- 

